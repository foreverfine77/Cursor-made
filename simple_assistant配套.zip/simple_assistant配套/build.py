import PyInstaller.__main__
import os
import sys
import shutil
import json

def check_resources():
    """检查必需的资源文件"""
    required_files = {
        'assistant_icon.png': '程序图标',
        'knowledge_base.json': '知识库文件',
        'notes.json': '笔记文件'
    }
    
    # 检查笔记文件是否存在，不存在则创建空的笔记库
    if not os.path.exists('notes.json'):
        with open('notes.json', 'w', encoding='utf-8') as f:
            json.dump({}, f, ensure_ascii=False, indent=4)
    
    missing_files = []
    for file, desc in required_files.items():
        if not os.path.exists(file):
            missing_files.append(f"{desc}（{file}）")
    
    if missing_files:
        print("错误：找不到以下必需文件：")
        for file in missing_files:
            print(f"- {file}")
        sys.exit(1)

def get_resource_path(relative_path):
    """获取资源文件的路径"""
    if hasattr(sys, '_MEIPASS'):
        return os.path.join(sys._MEIPASS, relative_path)
    return os.path.join(os.path.abspath("."), relative_path)

def modify_source_code():
    """修改源代码以支持打包后的资源访问"""
    with open('simple_assistant.py', 'r', encoding='utf-8') as f:
        content = f.read()
    
    # 添加资源路径获取函数
    resource_func = """
def get_resource_path(relative_path):
    if hasattr(sys, '_MEIPASS'):
        return os.path.join(sys._MEIPASS, relative_path)
    return os.path.join(os.path.abspath("."), relative_path)
"""
    
    # 修改文件路径的使用
    content = content.replace(
        'with open(\'knowledge_base.json\', \'r\', encoding=\'utf-8\') as file:',
        'with open(get_resource_path(\'knowledge_base.json\'), \'r\', encoding=\'utf-8\') as file:'
    )
    content = content.replace(
        'with open(\'notes.json\', \'r\', encoding=\'utf-8\') as file:',
        'with open(get_resource_path(\'notes.json\'), \'r\', encoding=\'utf-8\') as file:'
    )
    content = content.replace(
        'icon_path = "assistant_icon.png"',
        'icon_path = get_resource_path("assistant_icon.png")'
    )
    
    # 修改保存文件的路径
    content = content.replace(
        'with open(\'knowledge_base.json\', \'w\', encoding=\'utf-8\') as file:',
        'with open(get_resource_path(\'knowledge_base.json\'), \'w\', encoding=\'utf-8\') as file:'
    )
    content = content.replace(
        'with open(\'notes.json\', \'w\', encoding=\'utf-8\') as file:',
        'with open(get_resource_path(\'notes.json\'), \'w\', encoding=\'utf-8\') as file:'
    )
    
    # 在导入语句后添加资源路径函数
    import_end = content.find('class')
    modified_content = content[:import_end] + resource_func + content[import_end:]
    
    # 保存修改后的代码
    with open('temp_assistant.py', 'w', encoding='utf-8') as f:
        f.write(modified_content)

def main():
    """主函数"""
    print("开始打包程序...")
    
    # 检查资源文件
    print("检查资源文件...")
    check_resources()
    
    # 创建临时目录
    print("创建临时目录...")
    if not os.path.exists('build_temp'):
        os.makedirs('build_temp')
    
    # 修改源代码
    print("修改源代码...")
    modify_source_code()
    
    # 复制必需文件到临时目录
    print("复制资源文件...")
    shutil.copy('temp_assistant.py', 'build_temp/simple_assistant.py')
    shutil.copy('assistant_icon.png', 'build_temp/')
    shutil.copy('knowledge_base.json', 'build_temp/')
    shutil.copy('notes.json', 'build_temp/')
    
    # 切换到临时目录
    print("开始打包...")
    os.chdir('build_temp')
    
    # 执行打包
    PyInstaller.__main__.run([
        'simple_assistant.py',
        '--name=小通-通信知识助手',
        '--windowed',
        '--onefile',
        '--icon=assistant_icon.png',
        '--add-data=assistant_icon.png;.',
        '--add-data=knowledge_base.json;.',
        '--add-data=notes.json;.',
        '--clean',
        '--noconfirm'
    ])
    
    # 复制生成的文件到上级目录
    if os.path.exists('dist/小通-通信知识助手.exe'):
        if not os.path.exists('../dist'):
            os.makedirs('../dist')
        shutil.copy('dist/小通-通信知识助手.exe', '../dist/')
        print("\n打包成功！可执行文件位于 dist/小通-通信知识助手.exe")
    else:
        print("\n打包失败！请检查错误信息。")
    
    # 清理临时文件
    print("清理临时文件...")
    os.chdir('..')
    shutil.rmtree('build_temp')
    if os.path.exists('temp_assistant.py'):
        os.remove('temp_assistant.py')
    
    print("打包完成！")

if __name__ == '__main__':
    main() 