document.addEventListener('DOMContentLoaded', () => {
    // 获取元素
    const dogLogo = document.getElementById('dogLogo');
    const barkSound = document.getElementById('barkSound');
    const clickSound = document.getElementById('clickSound');
    
    // 初始化音频上下文
    let audioContext;
    
    // 在第一次点击时初始化音频上下文
    function initAudio() {
        if (!audioContext) {
            audioContext = new (window.AudioContext || window.webkitAudioContext)();
            document.removeEventListener('click', initAudio);
        }
    }
    
    document.addEventListener('click', initAudio);
    
    // 点击事件处理
    dogLogo.addEventListener('click', () => {
        barkSound.currentTime = 0;
        barkSound.play();
        dogLogo.classList.add('clicked');
        setTimeout(() => {
            dogLogo.classList.remove('clicked');
        }, 300);
    });
    
    // 修改 emoji 效果
    const emojis = ['🐶', '🐕', '🦮', '🐕‍🦺', '🐩', '❤️', '🌟', '✨'];
    const emojiContainer = document.getElementById('emoji-container');
    let lastMouseX = 0;
    let lastMouseY = 0;
    let isMoving = false;
    let moveTimer;

    document.addEventListener('mousemove', (e) => {
        const deltaX = Math.abs(e.clientX - lastMouseX);
        const deltaY = Math.abs(e.clientY - lastMouseY);
        const hasMoved = deltaX > 5 || deltaY > 5;

        if (hasMoved) {
            isMoving = true;
            createEmoji(e.clientX, e.clientY);
            clearTimeout(moveTimer);
            moveTimer = setTimeout(() => {
                isMoving = false;
            }, 100);
        }

        lastMouseX = e.clientX;
        lastMouseY = e.clientY;
    });

    function createEmoji(x, y) {
        if (!isMoving) return;
        const emoji = document.createElement('div');
        emoji.className = 'floating-emoji';
        emoji.textContent = emojis[Math.floor(Math.random() * emojis.length)];
        emoji.style.left = `${x}px`;
        emoji.style.top = `${y}px`;
        emojiContainer.appendChild(emoji);
        setTimeout(() => {
            emoji.remove();
        }, 1000);
    }

    // 点击声音处理函数
    function playClickSound() {
        try {
            clickSound.volume = 0.2;  // 降低音量
            clickSound.currentTime = 0;
            const playPromise = clickSound.play();
            
            if (playPromise !== undefined) {
                playPromise.catch(error => {
                    console.log('播放声音出错:', error);
                });
            }
        } catch (err) {
            console.log('播放声音时发生错误:', err);
        }
    }

    // 为整个文档添加点击事件
    document.body.addEventListener('mousedown', () => {
        playClickSound();
    }, true);

    // 添加书签编辑功能
    let currentEditingBookmark = null;

    // 创建编辑对话框
    const editDialog = document.createElement('div');
    editDialog.className = 'edit-dialog';
    editDialog.innerHTML = `
        <div class="dialog-content">
            <h3>编辑收藏</h3>
            <div class="edit-form">
                <input type="text" id="editUrl" placeholder="输入网址 (例如: https://www.example.com)">
                <input type="text" id="editName" placeholder="输入名称">
                <input type="text" id="editIcon" placeholder="输入图标URL">
            </div>
            <div class="dialog-buttons">
                <button id="saveEdit">保存</button>
                <button id="cancelEdit">取消</button>
            </div>
        </div>
    `;
    document.body.appendChild(editDialog);

    // 为所有书签添加右键编辑功能
    document.querySelectorAll('.bookmark-item').forEach(bookmark => {
        bookmark.addEventListener('contextmenu', (e) => {
            e.preventDefault();
            currentEditingBookmark = bookmark;
            showEditDialog(bookmark);
        });
    });

    // 显示编辑对话框
    function showEditDialog(bookmark) {
        const url = bookmark.href;
        const name = bookmark.querySelector('span').textContent;
        const icon = bookmark.querySelector('img').src;

        document.getElementById('editUrl').value = url;
        document.getElementById('editName').value = name;
        document.getElementById('editIcon').value = icon;

        editDialog.style.display = 'flex';
    }

    // 保存编辑
    document.getElementById('saveEdit').addEventListener('click', () => {
        if (currentEditingBookmark) {
            const url = document.getElementById('editUrl').value;
            const name = document.getElementById('editName').value;
            const icon = document.getElementById('editIcon').value;

            currentEditingBookmark.href = url;
            currentEditingBookmark.querySelector('span').textContent = name;
            currentEditingBookmark.querySelector('img').src = icon;
        }
        editDialog.style.display = 'none';
    });

    // 取消编辑
    document.getElementById('cancelEdit').addEventListener('click', () => {
        editDialog.style.display = 'none';
    });
}); 